import re

def lexer():

    import keyword as k
    fl=open("comment.txt","r")

    keyword=["drink", "food loop", "foodies loop", "hunger", "hungrier", "starving" , "stop", "deliver", "manager", "yes", "thankyou", "function", "anyother", "no", "receipt", "feed", "plate", "carryon"]
    dt=['rice', 'pizza', 'burger', 'drink']
    mo=['+','-','/','*','^']
    ro=["lesser", "greater", "ehigh", "elow"]
    ao=["equal"]
    lo=['also','either','never']
    icd=['++','--']
    pun=[",","(",")","}", ";","{", ]
    slcom = "#"
    mlcom = "!*"
    def q2():

        fk=fl.read()
        tokens=[]
       
        source=fk.split()
       # source=str(source)
        #source=source.split(")
        
        print("\tINPUT SOURCE : ")
        print(source,"\n\n")
      
        for word in source:               
            if word in keyword:
                 tokens.append(["Keyword", word])
            elif word in dt:
                tokens.append(["Word = ",word ,"data type", dt[word]])
            elif word in ro:
                tokens.append(["relational operator", word])
            elif word in lo:
                tokens.append(["Logical operator", word])
            elif word in icd:
                if word == '++':
                     tokens.append(["Increment operator", word])
                else:
                    tokens.append(["Decreement operator", word])
            elif word in mo:
                tokens.append(["Mathematical operator", word])
            elif word in ao:
                tokens.append(["Assigment operator", word])
            elif word in slcom:
                tokens.append(["Single line comment",word])
            elif word in mlcom:
                tokens.append(["Multi line comment",word])
            elif word in pun:
                tokens.append(["Punctuator", word])
            elif re.match("^[A-Z|a-z|_].*$", word):
                 tokens.append(["Identifier", word])
            elif re.match("^[0-9].*$", word):
                tokens.append(["Constant", word])

        fh = open("token.txt", "w+")
        for x in tokens:
             fh = open("token.txt", "a")
             fh.write(str(x)+"\n")
             fh.close()
        print("\tTOKENS:")
        print(tokens)
    q2()
    
def s1():
    import re

    Check = input('Enter for Declaration Statement: ')
    DT = ['drink', 'pizza', 'burger', 'rice']
    Tk = []
    Tk = Check.split(' ')
    print(Tk, "\n")


    def checkk(DataType, val):
        print("DATA TYPE " +val)
        if DataType == 'rice' and re.match('^[0-9]+$', val):
            return True
        elif DataType == 'burger' and re.match('^"[\w|\W]+"$', val):
            return True
        elif DataType == 'drink' and re.match('[+-]?\d+\.\d+', val):
            return True
        elif DataType == 'pizza' and re.match("^'[A-Za-z0-9]'$", val):
            return True
        else:
            return False

    def sd():
        err = False
        flag = True
        i = 0
        tipe = ""
        namee = ""
        while i < len(Tk):
            if Tk[i] in DT:
                flag = True
                while i < len(Tk) and flag == True:
                    if Tk[i] in DT:
                        tipe = Tk[i]
                        i += 1
                    else:
                        print("Invalid Data Type ")
                        err = True
                        i += 1
                    if re.match('^[a-zA-Z]+$', Tk[i]):
                        namee = Tk[i]
                        print ("Valid Variable Name")
                        i += 1
                    else:
                        print("ERROR: Invalid Variable Name")
                        err = True
                        i += 1
                    if Tk[i] == "equal":
                        print ("Mathematical Operator equal exists.")
                        i += 1
                    else:
                        print("Can not read '='")
                        err = True
                        i += 1
                    if checkk(tipe, Tk[i]):
                        tipe = ""
                        i += 1
                        print ( namee," DataType MisMatch")
                    else:
                        print( namee, "'Data Type Match")
                        err = True
                        i += 1
                
                    if Tk[i] == '.':
                        i + 1
                        flag = False
                    else:
                        print("End Terminator missing")
                        err = True
                        i += 1
            else:
                i += 1

        if (not err):
            print("Declaration statement is correct. No errors found. ")
    sd()
def s2():
    Check = input('Enter Your Single conditional Statement, Separated By Space: ')
    Conditional = ['hunger', 'hungrier', 'starving']
    ro=["lesser", "greater", "ehigh", "elow"]
    condBraces = ["(",")"]
    lo=['also','either','never']
    tokens = []
    tokens = Check.split(" ")
    print(tokens, "\n")
    def checkk(typee, value):
        print("datatype"+value)
    def sc():
        error = False
        flag = True
        i = 0
        namee = ""
        tipe = ""
        while i < len(tokens):
            if tokens[i] in Conditional:
                flag = True
                while i < len(tokens) and flag == True:
                    i+=1
                    if tokens[i] in condBraces:
                        print("Valid Braces")
                        i += 1
                    else:
                        print("Invalid BRACES")
                        error = True
                        i += 1
                    if re.match("^[A-Z|a-z|0-9].*$", tokens[i]):
                        namee = tokens[i]
                        i += 1
                    else:
                        print("ERROR: Invalid Variable/constant  Name")
                        error = True
                        i += 1
                    if tokens[i] == ro or lo:
                        print ("Token is an Operator")
                        i += 1
                    else:
                        print("Invalid Operator Inputted")
                        error = True
                        i += 1
                    if re.match("^[A-Z|a-z|0-9].*$", tokens[i]):
                        namee = tokens[i]
                        print("Valid Variable/Constant")
                        i += 1
                    else:
                        print("ERROR: Invalid Variable/Constant  Name")
                        error = True
                        i += 1
                    if checkk(tipe, tokens[i]):
                        tipe = ""
                        i += 1
                        print ( namee," DataType MisMatch")
                    else:
                        print( namee, "'s Syntax Match")
                        err = True
                        i += 1
                    if tokens[i].endswith(":"):
                        i + 1
                        print("Terminator Valid")
                    else:
                        print("ERROR: Invalid Terminator")
                        error = True
                        i += 1
                    if re.match("^[A-Z|a-z|_|{|}].*$", tokens[i]):
                        tokens.append(["Identifier", tokens[i]])
                    if re.match("^[0-9].*$", word):
                        tokens.append(["Constant", tokens[i]])
            else:
                i += 1
        if (not error):
            print("If statement is correct. No errors found. ")
    sc()
    
def main():
    lexer()
    s1()
    s2()

main()
