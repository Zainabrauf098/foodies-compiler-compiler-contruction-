import re
# Recursive Decent Parser for Conditional statement in food compiler statement.
inbuffer = input('Enter your input ,separated by space : ')
t = []
t = inbuffer.split(' ')
t.append('$')
print(t)
global i
i = -1


def R():
    iff()


def iff():
    if (id == 'hunger'):
        matcht('hunger')
        matcht('(')
        iden()
        con()
        exp()
        matcht(')')
        statement()
        if (id == 'hungrier'):
            statement()
        if (id == 'starving'):
            matcht('starving')
            statement()
    else:
        print('error')


def statement():
    if (id == '{'):
        matcht('{')
        if (id == 'hunger'):
            iff()
            matcht('}')
            matcht(';')
        elif re.match('^[a-zA-Z]+$', id):
            iden()
            matcht('}')
            matcht(';')
    else:
        if (id == 'hungrier'):
            matcht('hungrier')
            matcht('(')
            iden()
            con()
            exp()
            matcht(')')
            statement()
        else:
            print('error')


def exp():
    if (re.match("^[a-zA-Z]+$", id)):
        iden()
    elif (re.match("^[0-9]+$", id)):
        digits()
    else:
        print('error')


def con():
    if (id == "<"):
        matcht('<')
    elif (id == ">"):
        matcht('>')
    elif (id == "<="):
        matcht('<=')
    elif (id == ">="):
        matcht('>=')
    elif (id == "=="):
        matcht('==')
    else:
        print('error')


def iden():
    if re.match('^[a-zA-Z]+$', id):
        matcht(id)
    else:
        print('error')


def digits():
    if re.match('^[0-9]+$', id):
        matcht(id)
    else:
        print('error')


def nexttoken():
    global i
    i = i + 1
    nt = t[i]
    return nt


def matcht(t):
    print(t)
    global id
    if (id == t):
        id = nexttoken()
    else:
        print('error')


def main():
    global id
    id = nexttoken()
    R()
    if (id == '$'):
        print('Accept')
    else:
        print("Reject")


main()
